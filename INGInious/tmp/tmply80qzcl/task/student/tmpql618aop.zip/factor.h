#ifndef _FACTOR_H_
#define _FACTOR_H_

class Factor 
{
  public:
  Factor();
  ~Factor();
  int mostrarFactor();
  
  private:
  int numero;
  int factor;

};
#endif