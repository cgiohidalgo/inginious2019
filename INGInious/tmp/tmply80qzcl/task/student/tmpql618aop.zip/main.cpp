#include <iostream>
using namespace std;
#include "factor.h"

int main() {
Factor comprobarFactor;

comprobarFactor.mostrarFactor();
return 0;
}